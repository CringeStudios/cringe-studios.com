<?PHP
class WebPage
{
	// Declare all instance variables
	private $title = 'default title';
	private $charset = 'UTF-8';
	private $author = 'Mc BigFood';
	private $section = array();
	
	// Declaration Method showPage
    public function showPage() {
		
		$page  = "<!DOCTYPE html>\n";
		$page .= "<html>\n";
		$page .= $this->insertHeader();
		$page .= $this->insertBody();
		$page .= "</html>";
		
        echo $page;
    }
	
	private function insertHeader() {
		$head  = "<head>\n";
		$head .= "<meta charset=\"".$this->charset."\">\n";
		$head .= "<meta name=\"author\" content=\"".$this->author."\">\n";
		$head .= "<title>".$this->title."</title>\n";		
		$head .= "</head>\n";
		return $head;
	}
	
	private function insertBody() {
		$body  = "<body>\n";
		while($section = array_shift($this->section)) {
			$body .= $section;
		}
		$body .= "</body>\n";
		return $body;
	}
	
	public function addSection($headline,$content) {
		$output = "<section>\n";
		$output .= "<h1>$headline</h1>\n";
		$output .= "<p>$content</p>\n";
		$output .= "</section>\n";
		$this->section[] = $output;
	}
	
	public function setTitle($title) {
		$this->title = $title;
    }
	
	public function setCharset($charset) {
		$this->charset = $charset;
    }
	
	public function setAuthor($author) {
		$this->author = $author;
    }
}