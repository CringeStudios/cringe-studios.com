<?PHP
require_once 'classWebPage.inc.php';

$webPage = new WebPage();
$webPage->setCharset('UTF-8');
$webPage->setTitle('website-3');
$webPage->setAuthor('Jürgen Heym');
$webPage->addSection('Headline section 1','Content section 1');
$webPage->addSection('Headline section 2','Content section 2');
$webPage->showPage();
?>